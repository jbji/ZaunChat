#include "safeutilities.h"

SafeUtilities::SafeUtilities()
{

}


QString SafeUtilities::GetPasswordHash(QString password){
    return password;
}
