#ifndef DATAMODEL_H
#define DATAMODEL_H

//数据模型 汇总文件
#include "DataModel/Msg/msg.h"
#include "DataModel/Msg/msgtype.h"
#include "DataModel/chatmessage.h"
#include "DataModel/userinfo.h"

#endif // DATAMODEL_H
